import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dalili.personmap',
  appName: 'دليلي',
  webDir: 'dist/public',
  server: {
    androidScheme: 'https',
  },
};

export default config;
