# Dalili Android project

This folder is the Android Studio project. The export also includes the
Capacitor Android plugin source folders at the relative paths referenced by
`capacitor.settings.gradle`, so the Android project can build without running
`pnpm` first.

## Requirements

- Android Studio with Android SDK Platform 36 and Android SDK Build-Tools 36
- Android Studio's bundled Gradle JDK (Java 21)
- Internet access for the first Gradle sync and Android dependency downloads

## Open and build on Windows

1. Extract the complete ZIP while preserving its folder structure.
2. In Android Studio, open:
   `artifacts/person-map-vault/android`
3. Accept the Gradle sync prompt and wait for dependencies to download.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at:
   `artifacts/person-map-vault/android/app/build/outputs/apk/debug/app-debug.apk`

You can also build from PowerShell in the Android project folder:

```powershell
.\gradlew.bat assembleDebug
```

The ZIP contains the web assets already synced into
`app/src/main/assets/public`, the generated Capacitor runtime configuration,
the Capacitor TypeScript configuration, and the Android sources for the
installed Capacitor plugins. To include later website changes, use the full
Replit project and run `pnpm --filter @workspace/person-map-vault run cap:sync`
before exporting again.

This produces a debug APK for testing. A release APK requires signing with
your own Android signing key; no signing key is included.
