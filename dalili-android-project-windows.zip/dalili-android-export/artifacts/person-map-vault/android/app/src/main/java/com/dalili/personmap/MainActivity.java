package com.dalili.personmap;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
